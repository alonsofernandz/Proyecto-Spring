# todoAPI
repo for my youtube video "create your first REST API using java, springboot, jpa and mysql"
https://youtu.be/OkD1wBpPsNM
